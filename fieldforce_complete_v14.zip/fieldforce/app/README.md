# FieldForce — Mobile App (Phase 1: UI)

Field Sales Force Management & Workforce Tracking.
This package is the **Flutter mobile app UI** — screens, theme and navigation.
Backend, GPS, and API integration come in the next phases.

---

## What is inside

| Screen | Path | Status |
|---|---|---|
| Splash | `/splash` | Done |
| Login + forgot password | `/login` | Done |
| Dashboard (duty card, stats, targets, route) | `/home` | Done |
| Visits + geofence check-in state | `/visits` | Done |
| Customers + detail sheet | `/customers` | Done |
| Tasks | `/tasks` | Done |
| Profile + privacy sheet | `/profile` | Done |
| Attendance | `/attendance` | Done |

Working in this build: duty start / break / resume / end with a live timer,
visit filters, customer search, offline banner (toggle it from Profile).

---

## Run it in Android Studio

1. Unzip the folder anywhere, e.g. `D:\projects\field_force`.
2. Android Studio → **File → Open** → select the `field_force` folder.
3. Terminal (inside Android Studio):
   ```
   flutter pub get
   ```
4. Pick an emulator or a connected phone, then press **Run** (or `flutter run`).

Requires Flutter 3.19+ and Dart 3.3+. Check with `flutter doctor`.

If `pub get` fails, run `flutter clean` and try again.

---

## Design

- **Ink navy** (`#0E1225`) is the control-room surface — used for the duty card,
  which is the loudest element on the home screen.
- **Amber** (`#FF7A2F`) means one thing only: duty is running. It is never
  decoration.
- **Indigo** (`#4C5CE5`) is for navigation and neutral actions.
- Green / amber / red carry attendance and visit status, nothing else.

All colors, spacing and radii live in `lib/core/theme/`. Change them there and
the whole app follows.

---

## Folder structure

```
lib/
  core/
    theme/        colors, spacing, light + dark ThemeData
    utils/        duration, date and currency formatters
  features/
    splash/ auth/ dashboard/ attendance/ visits/ customers/ tasks/ profile/
  shared/
    models/       Customer, Visit, FieldTask, TargetProgress + demo data
    widgets/      AppButton, AppCard, StatTile, StatusChip, EmptyState, ProgressBar
  routing/        GoRouter config + bottom-nav shell
  state/          Riverpod controllers (duty / break timer, connectivity)
  main.dart
```

---

## Demo data

Everything on screen comes from `lib/shared/models/mock_data.dart`.
In Phase 2 this file gets replaced by API responses — no screen code changes,
because screens only read the model classes.

---

## Next phases

- **Phase 2** — Backend: PostgreSQL schema, auth, employee onboarding APIs
- **Phase 3** — Wire the app to the API (Dio, token storage, refresh rotation)
- **Phase 4** — Real GPS: background tracking, geofence check-in, anomaly flags
- **Phase 5** — React + TypeScript admin dashboard with the live map
